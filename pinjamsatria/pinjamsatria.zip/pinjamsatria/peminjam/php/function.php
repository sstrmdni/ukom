<?php
$conn = mysqli_connect("localhost", "root", "", "ukom_satria");

if (isset($_POST['addpinjam'])) {
    $nama = $_POST['nama'];
    $qty = $_POST['qty'];
    $user = $_POST['user'];
    date_default_timezone_set('Asia/Jakarta');
    $date = date('Y-m-d H:i:s');

    $select = mysqli_query($conn, "SELECT id_barang, lokasi, jumlah_barang FROM alatbahan WHERE nama_barang = '$nama'");
    $assoc = mysqli_fetch_assoc($select);
    $idb = $assoc['id_barang'];
    $lokasi = $assoc['lokasi'];
    $jumlah = $assoc['jumlah_barang'];
    $total = $jumlah - $qty;
    if ($select) {
        $insert = mysqli_query($conn, "INSERT INTO pinjamalat (peminjam, tgl_pinjam, id_barang, nama_barang, jml_barang, kondisi) VALUES ('$user', '$date', '$idb', '$nama', '$qty', 'dipinjam')");
        if ($insert) {
            $insert2 = mysqli_query($conn, "INSERT INTO barang_keluar (id_barang, nama_barang, tgl_keluar, jml_keluar, lokasi, penerima, jml_sebelum, jml_sesudah) VALUES ('$idb', '$nama', '$date', '$qty', '$lokasi', '$user', '$jumlah', '$total')");
            if($insert2){
                $update = mysqli_query($conn, "UPDATE alatbahan SET jumlah_barang = '$total' WHERE id_barang = '$idb'");
                if($update){
                    $select2 = mysqli_query($conn, "SELECT jml_keluar, total_barang FROM stok WHERE id_barang = '$idb'");
                    $array = mysqli_fetch_assoc($select2);
                    $keluar = $array['jml_keluar'];
                    $all = $array['total_barang'];
                    $keluar1 = $qty +  $keluar;
                    $all1 = $qty + $all;
                    if($select2){
                        $stok = mysqli_query($conn, "UPDATE stok SET jml_keluar = '$keluar1', total_barang = '$all1' WHERE id_barang = '$idb'");
                        if($stok){
                            header('location:?url=history');
                        }
                    }
                }
            }
        }
    }
}

if(isset($_POST['kembali'])){
    $idt = $_POST['idt'];
    $idb = $_POST['idb'];
    $qty = $_POST['qty'];
    date_default_timezone_set('Asia/Jakarta');
    $date = date('Y-m-d H:i:s');
    $select = mysqli_query($conn, "SELECT nama_barang, jumlah_barang FROM alatbahan WHERE id_barang = '$idb'");
    $assoc = mysqli_fetch_array($select);
    $nama = $assoc['nama_barang'];
    $jumlah = $assoc['jumlah_barang'];
    $total = $qty + $jumlah;

    $update = mysqli_query($conn, "UPDATE pinjamalat SET tgl_kembali = '$date', kondisi = 'dikembalikan' WHERE id_pinjam = '$idt'");
    if($update){
        $insert = mysqli_query($conn, "INSERT INTO barang_masuk(id_barang, nama_barang, tgl_masuk, jml_sebelum, jml_masuk, jml_sesudah) VALUES ('$idb', '$nama', '$date', '$jumlah', '$qty', '$total')");
        if($insert){
            $update = mysqli_query($conn, "UPDATE alatbahan SET jumlah_barang = '$jumlah' WHERE id_barang = '$idb'");
            if($update){
                $ambil = mysqli_query($conn, "SELECT jml_masuk, total_barang FROM stok WHERE id_barang = '$idb'");
                $array = mysqli_fetch_array($ambil);
                $masuk = $assoc['jml_masuk'];
                $barang = $assoc['total_barang'];
                $masuk1 = $masuk + $qty;
                $barang1 = $barang + $qty;
                if($ambil){
                    $stok = mysqli_query($conn, "UPDATE stok SET jml_masuk = '$masuk1', total_barang = '$barang1' WHERE id_barang = '$idb'");
                    if($stok){
                        header("location:?url=history");
                    }
                }
            }
        }
    }
}

if(isset($_POST['edit'])){
    $qty = $_POST['qty'];
    $idt = $_POST['idt'];
    $date = $_POST['date'];

    $select = mysqli_query($conn, "UPDATE pinjamalat SET jml_barang = '$qty', tgl_kembali = '$date'");
}

if(isset($_POST['hapus'])){
    $idt = $_POST['idt'];

    $delete = mysqli_query($conn, "DELETE FROM pinjamalat WHERE id_pinjam = '$idt'");
}
?>