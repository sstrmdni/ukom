    <div class="row mt-4">

        <div class="col-12">

            <div class="card mb-4">

                <div class="card-header pb-0 mb-2">

                    <h6>List History Pinjam <?= $_SESSION['nama_user']; ?></h6>

                </div>

                <div class="card-body px-0 pt-0 pb-2">

                    <div class="table-responsive">

                        <table class="table align-items-center justify-content-center mb-0" style="width:100%" id="myTable">

                            <thead>

                                <tr>

                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        No</th>

                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Gambar</th>

                                    <th data-column="nama" class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Nama Item</th>

                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Tgl Kembali</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Tgl Keluar</th>

                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Jumlah</th>

                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Status</th>

                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Edit</th>

                                </tr>

                            </thead>

                            <tbody>

                                <?php

                                $per_page = 10;



                                $query_total = mysqli_query($conn, "SELECT COUNT(*) AS total FROM pinjamalat");

                                $row_total = mysqli_fetch_assoc($query_total);

                                $total_data = $row_total['total'];

                                $total_pages = ceil($total_data / $per_page);

                                $page_number = isset($_GET['page']) ? (int) $_GET['page'] : 1;

                                $start = ($page_number - 1) * $per_page;

                                $ambil = mysqli_query($conn, "SELECT *, pinjamalat.kondisi AS yujin FROM pinjamalat INNER JOIN alatbahan ON alatbahan.id_barang = pinjamalat.id_barang WHERE peminjam = '$_SESSION[nama_user]'");

                                $i = ($page_number - 1) * $per_page + 1;

                                $max_buttons = 5;

                                $start_page = max(1, $page_number - floor($max_buttons / 2));

                                $end_page = min($total_pages, $start_page + $max_buttons - 1);

                                while ($data = mysqli_fetch_array($ambil)) {
                                    $gambar = $data['image'];

                                    if ($gambar == null) {

                                        // jika tidak ada gambar

                                        $img = '<img src="/assets/img/noimageavailable.png" class="zoomable avatar avatar-sm rounded-circle me-2">';
                                    } else {

                                        //jika ada gambar

                                        $img = '<img src="../assets/img/' . $gambar . '" class="zoomable avatar avatar-sm rounded-circle me-2">';
                                    }

                                ?>

                                    <tr class="parentRow">

                                        <td>

                                            <p class="text-sm font-weight-bold mb-0 text-center">
                                                <?= $i++; ?>
                                            </p>

                                        </td>

                                        <td>



                                            <div class="d-flex px-1">



                                                <div>



                                                    <?= $img; ?>



                                                </div>


                                            </div>



                                        </td>
                                        <td class="text-wrap">
                                            <span class="text-xs font-weight-boldn text-wrap">
                                                <?= $data['nama_barang']; ?></span>
                                        </td>
                                        <td class="text-wrap">
                                            <span class="text-xs font-weight-bold text-wrap">
                                                <?= $data['tgl_pinjam']; ?>
                                            </span>

                                        </td>
                                        <td>

                                            <span class="text-xs font-weight-bold">
                                                <?= $data['tgl_kembali']; ?>
                                            </span>

                                        </td>
                                        <td>
                                            <span class="text-xs font-weight-bold">
                                                <?= $data['jml_barang']; ?>
                                            </span>
                                        </td>
                                        <form action="" method="post">
                                        <td><span class="text-xs font-weight-bold text-wrap">
                                                <?php
                                                if ($data['yujin'] == 'dipinjam') {
                                                    echo '<button type="submit" class="btn btn-info mt-2" name="kembali[' . $data['id_pinjam'] . ']">Return</button>';
                                                } else {
                                                    echo 'Sudah Dikembalikan';
                                                }
                                                ?>
                                                <input type="hidden" name="idt" value="<?= $data['id_pinjam']; ?>">
                                                <input type="hidden" name="idb" value="<?= $data['id_barang']; ?>">
                                                <input type="hidden" name="qty" value="<?= $data['jml_barang']; ?>">
                                            </span></td>
                                            <td class="text-center">
                                            <a data-bs-toggle="modal" data-bs-target="#edit<?= $data['id_pinjam']; ?>">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                        </td>
                                    </tr>

                                    </tr>
                                    </form>

                                <?php

                                }

                                ?>

                            </tbody>

                        </table>

                    </div>


                </div>


                <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>



                <script>
                    $(document).ready(function() {

                        // Initialize DataTable for the parent table only

                        $('.parentTable').DataTable({

                            // Add your DataTable options and configurations here

                            // For example:

                            // "paging": false,

                            // "searching": false,

                            // "ordering": false,

                            // "info": false,

                        });

                    });
                </script>

            </div>

        </div>

    </div>

    </div>

    </div>
    <div class="modal fade" id="edit<?= $data['id_pinjam']; ?>">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
                                                    <button type="button" class="btn-close bg-danger" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body" style="max-height: 80vh; overflow-y: auto;">
                                                        <div class="container">
                                                            <div class="row">
                                                                <div class="col-lg-6">
                                                                    <label for="">Quantity</label>
                                                                    <input class="form-control" value="<?= $data['jml_barang']; ?>" type="text" pattern="\+[0-9]+" name="qty">
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <label for="">Date</label>
                                                                    <input type="datetime-local" value="<?= $data['tgl_pinjam'];?>" class="form-control">
                                                                </div>
                                                                <input type="hidden" value="<?= $data['id_pinjam']; ?>" name="idt">
                                                                <div class="text-end mt-4">
                                                                    <button class="btn btn-danger" name="hapus">Hapus</button>
                                                                    <button class="btn btn-warning" name="edit">Edit</button>
                                                                </div>
                                                            </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>